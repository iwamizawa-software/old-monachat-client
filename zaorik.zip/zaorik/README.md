# old-monachat-client


## 実行準備


1. [https://nodejs.org/](https://nodejs.org/)からnode.jsを適当にインストール　すでに入ってるなら不要
2. [zaorik.zip](https://iwamizawa-software.github.io/old-monachat-client/zaorik.zip)をダウンロードして解凍
3. フォルダ内にあるinstallというファイルをinstall.batに名前を変更し実行
4. クレボの場合はエクスプローラで%PROGRAMFILES(X86)%\clairvoを開くか、クレボが入ってるフォルダを開いて、そこにzaorikのMonaGadget4を入れて上書きする
5. ねむくらの場合はねむくらフォルダ内のchatconfentrance.txtを開いて、「srvURL=monachat.dyndns.org」を「srvURL=localhost」に変える


## 実行方法


- startを実行　出てきた黒い画面はそのままにする
- クライアントを起動
